number1 = Number(prompt("Enter first integer: "));
number2 = Number(prompt("Enter second integer: "));
console.log(`${number1} + ${number2} = ${number1 +number2} `);
console.log(`${number1} - ${number2} = ${number1 -number2} `);
console.log(`${number1} x ${number2} = ${number1 *number2} `);
console.log(`${number1} : ${number2} = ${number1 /number2} `);
console.log(`${number1} % ${number2} = ${number1 %number2} `);
